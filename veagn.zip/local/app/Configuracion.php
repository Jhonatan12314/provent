<?php

namespace App;
use Illuminate\Database\Eloquent\Model;

class Configuracion extends Model
{

protected $table="configuracion";

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */


    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */


}
