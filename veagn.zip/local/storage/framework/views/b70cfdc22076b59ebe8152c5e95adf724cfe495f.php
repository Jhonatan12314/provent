<?php $__env->startSection('title', 'Detalle'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Inner Header-->
    <section class="inner-banner2 clearfix">
      <div class="container clearfix">


      <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
     
        <h2><?php echo e($categoria->nombre); ?></h2>  
      </div>
    </section>
    <section class="breadcumb-wrapper">
      <div class="container clearfix">
        <ul class="breadcumb">
          <li><a href="<?php echo e(url('index')); ?>"><i class="fa fa-home"></i> Inicio</a></li>
          <li><a href="<?php echo e(url('solutions')); ?>">Productos</a></li>
          <li><span>Detalles</span></li>
        </ul>
      </div>
    </section>
    <!-- Projects  Details-->
    <section class="core-projects sectpad">
      <div class="container clearfix">
        <div class="pro-det-img"><img src="<?php echo e(url($categoria->imagen)); ?>" alt=""></div>
        <div class="pro-content clearfix">
          <h1><?php echo e($categoria->nombre); ?></h1>
          <h4>Descripción</h4>
          <p><?php echo e(str_limit(strip_tags($categoria->descripcion), 150)); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>