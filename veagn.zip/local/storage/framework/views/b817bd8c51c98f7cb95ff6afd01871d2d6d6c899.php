 <div class="sidebar" data-active-color="rose" data-background-color="black" data-image="../assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of active element of the sidebar using: data-active-color="purple | blue | green | orange | red | rose"
        Tip 2: you can also add an image using data-image tag
        Tip 3: you can change the color of the sidebar with data-background-color="white | black"
    -->
            <div class="logo">
                <a href="http://www.indexceed.com/" class="simple-text">
                    By Indexceed
                </a>
            </div>
            <div class="sidebar-wrapper">

                <div class="user">
                    <div class="photo">
                        <img src="<?php echo e(url('public/frontend/images/user.jpg')); ?>"  />
                    </div>
                    <div class="info">
                        <a data-toggle="collapse" href="#collapseExample" class="collapsed">
                            <?php echo e(Auth::user()->nombre); ?>

                            <b class="caret"></b>
                        </a>
                        <div class="collapse" id="collapseExample">
                            <ul class="nav">
                                <li>
                                    <a href="#">Perfil</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('admin/logout')); ?>">Salir</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <ul class="nav">
                    <?php if($route=="dashboard"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a href="<?php echo e(url('admin/dashboard')); ?>">
                            <i class="material-icons">dashboard</i>
                            <p>Inicio</p>
                        </a>
                    </li>


                    <?php if($route=="categorias"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a  href="<?php echo e(url('admin/categorias')); ?>">
                            <i class="material-icons">list</i>
                            <p>Categorías </p>
                        </a>
                    </li>


                    <?php if($route=="productos"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a href="<?php echo e(url('admin/productos')); ?>">
                        <i class="material-icons">store</i>
                            
                            <p>Productos</p>
                        </a>
                    </li>


                    <?php if($route=="clientes"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a href="<?php echo e(url('admin/clientes')); ?>">
                            <i class="material-icons">person</i>
                            <p>Clientes</p>
                        </a>
                    </li>


                    <?php if($route=="noticias"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a href="<?php echo e(url('admin/noticias')); ?>">
                            <i class="material-icons">insert_comment</i>
                            <p>Noticias</p>
                        </a>
                    </li>    

                    <?php if($route=="servicios"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a href="<?php echo e(url('admin/servicios')); ?>">
                            <i class="material-icons">star</i>
                            <p>Servicios</p>
                        </a>
                    </li>  

                    <?php if($route=="sliders"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a href="<?php echo e(url('admin/sliders')); ?>">
                            <i class="material-icons">image</i>
                            <p>Slider</p>
                        </a>
                    </li>


                    <?php if($route=="configuracion"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a  href="<?php echo e(url('admin/configuracion')); ?>">
                        <i class="material-icons">settings</i>
                            <p>Configuración</p>
                        </a>
                    </li>

                    <?php if($route=="popup"): ?>
                    <li class="active">
                    <?php else: ?>
                    <li>
                    <?php endif; ?>
                        <a  href="<?php echo e(url('admin/popup')); ?>">
                        <i class="material-icons">settings</i>
                            <p>PopUp</p>
                        </a>
                    </li>


                </ul>
            </div>
        </div>
