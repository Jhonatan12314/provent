<?php $__env->startSection('title', 'Noticias'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Inner Header-->
    <section class="inner-banner2 clearfix">
      <div class="container clearfix">
        <h2>Noticias</h2>
      </div>
    </section>
    <section class="breadcumb-wrapper">
      <div class="container clearfix">
        <ul class="breadcumb">
          <li><a href="index">Inicio</a></li>
          <li><span>Noticias</span></li>
        </ul>
      </div>
    </section>
    <!-- News Page-->
    <section class="core-projects sectpad">
      <div class="container clearfix">
        <div class="row">
        
          <div class="col-md-12 col-sm-12 pull-right">
            <!-- News-->
            <div class="single-post-wrapper">

            <?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

            <article class="single-blog-post img-cap-effect">
             <?php if($noticia->imagen!=""): ?>
                <div class="img-box"><a href="<?php echo e(url('Noticia')); ?>/<?php echo e($noticia->id); ?>" class="image_hover"><img src="<?php echo e($noticia->imagen); ?>" alt="" class="img-responsive zoom_img_effect"></a></div>
                <?php else: ?>
                <div class="img-box"><a href="<?php echo e(url('Noticia')); ?>/<?php echo e($noticia->id); ?>" class="image_hover"><img src="<?php echo e(url('public/frontend/images/sinimagen.png')); ?>" alt="" class="img-responsive zoom_img_effect"></a></div>
                <?php endif; ?>

                
                
                <h6><?php echo e($noticia->cretaed_at); ?></h6>
                <h3><?php echo e($noticia->titulo); ?></h3>
                <p><?php echo e(str_limit(strip_tags($noticia->descripcion), 150)); ?></p>
                <a href="<?php echo e(url('Noticia')); ?>/<?php echo e($noticia->id); ?>"" class="read-more btn submit">Leer más</a>
              </article>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <!-- News 1-->
              
            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>