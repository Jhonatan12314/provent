<?php $__env->startSection('title', 'Administrador'); ?>

<?php $__env->startSection('content'); ?>

 <div class="wrapper">
        <div class="main-panel">
                  <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-minimize">
                        <button id="minimizeSidebar" class="btn btn-round btn-white btn-fill btn-just-icon">
                            <i class="material-icons visible-on-sidebar-regular">more_vert</i>
                            <i class="material-icons visible-on-sidebar-mini">view_list</i>
                        </button>
                    </div>
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"> Configuraci&oacute;n </a>
                    </div>
                </div>
            </nav>
            <div class="content">
                <div class="container-fluid">
             
                    <div class="row">
                    <form method="post" action="<?php echo e(url('admin/configuracion/create')); ?>">
                     <?php echo e(csrf_field()); ?>

                    <div align="right">
                     <button type="submit" class="btn btn-fill btn-rose">Guardar</button>
                     </div>

                     <?php if($configuracion): ?>
                     <div class="col-md-12">
                     <div class="col-md-4">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Redes Sociales</h4>
                                  
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-facebook-square"></i> Facebook
                                            <input type="text" name="facebook" value="<?php echo e($configuracion->facebook); ?>" class="form-control" >
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-twitter"></i> Twitter
                                            <input type="text" name="twitter" value="<?php echo e($configuracion->twitter); ?>" class="form-control" >
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-youtube"></i> Youtube
                                            <input type="text" name="youtube" value="<?php echo e($configuracion->youtube); ?>" class="form-control" >
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-pinterest"></i> Pinterest
                                            <input type="text" name="pinterest" value="<?php echo e($configuracion->pinterest); ?>" class="form-control" ">
                                        <span class="material-input"></span></div> 
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-instagram"></i> Instagram
                                            <input type="text" name="instagram" value="<?php echo e($configuracion->instagram); ?>" class="form-control" ">
                                        <span class="material-input"></span></div> 

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-skype"></i> Skype
                                            <input type="text" name="skype" value="<?php echo e($configuracion->skype); ?>" class="form-control" ">
                                        <span class="material-input"></span></div>  

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-google-plus"></i> Google+
                                            <input type="text" name="google" value="<?php echo e($configuracion->google); ?>" class="form-control" ">
                                        <span class="material-input"></span></div>  

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-linkedin"></i> Linkedin
                                            <input type="text" name="linkedin" value="<?php echo e($configuracion->linkedin); ?>" class="form-control" ">
                                        <span class="material-input"></span></div>  

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-whatsapp"></i> Whatsapp
                                            <input type="text" name="whatsapp" value="<?php echo e($configuracion->whatsapp); ?>" class="form-control" ">
                                        <span class="material-input"></span></div>                             
                      
                                </div>
                                <!-- end content-->
                            </div>
                            </div>
                            <div class="col-md-4">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Información Nosotros</h4>
                                     <div class="form-group label-floating is-empty">
                                            <label class="">Historia</label>
                                            <textarea id="textarea5" name="historia"><?php echo e($configuracion->historia); ?></textarea>
                                        <span class="material-input"></span></div>


                                     <div class="form-group label-floating is-empty">
                                            <label class="">Misión</label>
                                            <textarea id="textarea1" name="mision"><?php echo e($configuracion->mision); ?></textarea>
                                        <span class="material-input"></span></div>
                           
                                        <div class="form-group label-floating is-empty">
                                            <label class="">Visión</label>
                                            <textarea id="textarea2" name="vision"><?php echo e($configuracion->vision); ?></textarea>
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="">Valores</label>
                                            <textarea id="textarea3" name="valores"><?php echo e($configuracion->valores); ?></textarea>
                                        <span class="material-input"></span></div>
                                       
                                        <div class="form-group label-floating is-empty">
                                            <label class="">Objetivos</label>
                                            <textarea id="textarea4" name="objetivos"><?php echo e($configuracion->objetivos); ?></textarea>
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="">Imagen</label>
                                            <input type="text" name="imagen" value="<?php echo e($configuracion->imagen); ?>" class="form-control" id="imagen">
                                        <span class="material-input"></span></div>                                     
                          
                                </div>
                                <!-- end content-->
                            </div>
                            </div>
                            <div class="col-md-4">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Contacto</h4>
                                   
                                        <div class="form-group label-floating is-empty">
                                            <label class="">Dirección</label>
                                            <input type="text" name="direccion" value="<?php echo e($configuracion->direccion); ?>" class="form-control" id="direccion">
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="">Email</label>
                                            <input type="text" name="email" value="<?php echo e($configuracion->email); ?>" class="form-control" id="email">
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="">Teléfono</label>
                                            <input type="text" name="telefono" value="<?php echo e($configuracion->telefono); ?>" class="form-control" id="tel">
                                        <span class="material-input"></span></div>                             
                                  
                                </div>
                                <!-- end content-->
                            </div>
                            </div>                                                        
                            <!--  end card  -->
                        </div>
                     <?php else: ?>
                                         <div class="col-md-12">
                     <div class="col-md-4">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Redes Sociales</h4>
                                  
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-facebook-square"></i> Facebook
                                            <input type="text" name="facebook" class="form-control" >
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-twitter"></i> Twitter
                                            <input type="text" name="twitter" class="form-control" >
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-youtube"></i> Youtube
                                            <input type="text" name="youtube" class="form-control" >
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-pinterest"></i> Pinterest
                                            <input type="text" name="pinterest" class="form-control" ">
                                        <span class="material-input"></span></div>  
                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-instagram"></i> Instagram
                                            <input type="text" name="instagram" class="form-control" ">
                                        <span class="material-input"></span></div>

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-skype"></i> Skype
                                            <input type="text" name="skype" class="form-control" ">
                                        <span class="material-input"></span></div>  

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-linkedin"></i> Linkedin
                                            <input type="text" name="linkedin" class="form-control" ">
                                        <span class="material-input"></span></div>  

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-google-plus"></i> Google+
                                            <input type="text" name="google" class="form-control" ">
                                        <span class="material-input"></span></div>  

                                        <div class="form-group label-floating is-empty">
                                            <i class="fa fa-whatsapp"></i> Whatsapp
                                            <input type="text" name="whatsapp" class="form-control" ">
                                        <span class="material-input"></span></div>                            
                      
                                </div>
                                <!-- end content-->
                            </div>
                            </div>
                            <div class="col-md-4">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Información Nosotros</h4>

                                      <div class="form-group label-floating is-empty">
                                            <label class="">Historia</label>
                                            <input type="text" name="historia" value="<?php echo e($configuracion->historia); ?>" class="form-control" id="historia">
                                        <span class="material-input"></span></div>

                                           <div class="form-group label-floating is-empty">
                                            <label class="control-label">Misión</label>
                                            <input type="text" name="mision" class="form-control" id="mision">
                                        <span class="material-input"></span></div>
                           
                                        <div class="form-group label-floating is-empty">
                                            <label class="control-label">Visión</label>
                                            <input type="text" name="vision" class="form-control" id="vision">
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="control-label">Valores</label>
                                            <input type="text" name="valores" class="form-control" id="valores">
                                        <span class="material-input"></span></div>
                                     
                                        <div class="form-group label-floating is-empty">
                                            <label class="control-label">Objetivos</label>
                                            <input type="text" name="objetivos" class="form-control" id="objetivos">
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="control-label">Imagen</label>
                                            <input type="text" name="imagen" class="form-control" id="imagen">
                                        <span class="material-input"></span></div>                                     
                          
                                </div>
                                <!-- end content-->
                            </div>
                            </div>
                            <div class="col-md-4">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Contacto</h4>
                                   
                                        <div class="form-group label-floating is-empty">
                                            <label class="control-label">Direccón</label>
                                            <input type="text" name="direccion" class="form-control" id="direccion">
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="control-label">Email</label>
                                            <input type="text" name="email" class="form-control" id="email">
                                        <span class="material-input"></span></div>
                                        <div class="form-group label-floating is-empty">
                                            <label class="control-label">Teléfonno</label>
                                            <input type="text" name="telefono" class="form-control" id="tel">
                                        <span class="material-input"></span></div>                             
                                  
                                </div>
                                <!-- end content-->
                            </div>
                            </div>                                                        
                            <!--  end card  -->
                        </div>
                        <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>