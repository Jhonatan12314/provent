<?php $__env->startSection('title', 'Administrador'); ?>

<?php $__env->startSection('content'); ?>

 <div class="wrapper">
        <div class="main-panel">
                  <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-minimize">
                        <button id="minimizeSidebar" class="btn btn-round btn-white btn-fill btn-just-icon">
                            <i class="material-icons visible-on-sidebar-regular">more_vert</i>
                            <i class="material-icons visible-on-sidebar-mini">view_list</i>
                        </button>
                    </div>
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"> Slider </a>
                    </div>
                </div>
            </nav>
            <div class="content">
                <div class="container-fluid">
             
                    <div class="row">
                    <form method="post" action="<?php echo e(url('admin/popup/create')); ?>">
                     <?php echo e(csrf_field()); ?>

                    <div align="right">
                     <button type="submit" class="btn btn-fill btn-rose">Guardar</button>
                     </div>

                     <?php if($configuracion): ?>
                     <div class="col-md-12">
                     <div class="col-md-12">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Popup</h4>
                                    <textarea id="textarea1" name="descripcion"><?php echo e($configuracion->popup); ?></textarea> 

                                    <div class="form-group label-floating is-empty">
                                            <?php if($configuracion->popupactivo): ?>
                                           <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="activo" checked=""><span class="checkbox-material"></span>Activo
                                            </label>
                                        </div>

                                            <?php else: ?>
                                           <div class="checkbox">
                                            <label>
                                                <input type="checkbox" name="activo"><span class="checkbox-material"></span>Activo
                                            </label>
                                        </div>

                                            <?php endif; ?>
                                            

                                        </div>
                                    
                      
                                </div>
                                <!-- end content-->
                            </div>
                            </div>
                                                       
                            <!--  end card  -->
                        </div>
                     <?php else: ?>
                                         <div class="col-md-12">
                     <div class="col-md-12">
                            <div class="card">
                                <div class="card-content">
                                    <h4 class="card-title">Popup</h4>
                                    <textarea id="textarea1" name="descripcion"></textarea>   

                                    <div class="form-group label-floating is-empty">
                                            <label >Activado</label>
                                            <input type="checkbox" name="activo">
                                        <span class="material-input"></span></div>        
                      
                                </div>
                                <!-- end content-->
                            </div>
                            </div>
                                                                                 
                            <!--  end card  -->
                        </div>
                        <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>