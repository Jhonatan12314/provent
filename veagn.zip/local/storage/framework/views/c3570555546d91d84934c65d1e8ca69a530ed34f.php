<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startSection('content'); ?>


    <!-- Inner Header-->
    <section class="inner-banner2 clearfix">
      <div class="container clearfix">
        <h2>Clientes</h2>
      </div>
    </section>
    <section class="breadcumb-wrapper">
      <div class="container clearfix">
        <ul class="breadcumb">
          <li><a href="index">Inicio</a></li>
          <li><span>Clientes</span></li>
        </ul>
      </div>
    </section>
    <!-- Project  Page-->
    <section class="core-projects sectpad-t">
      <div class="container clearfix">
        <h1>¿Quienes son nuestros clientes?</h1>
     
      </div>
    </section>
    <!-- Testimonials clients-->
        <section class="diff-offer-wrapper">
      <div class="container">
      <div class="row diff-offer">
          <ul>
            
            <li class="we-offer-cont2">
              <p style="text-align: justify;">Para Veagn los clientes son la gran apuesta de valor, el verdadero aval de la compañía y la mayor garantía de nuestra continuidad. Por este motivo, les agradecemos la confianza que nos han brindado durante toda nuestra trayectoria, un apoyo que ha permitido que seamos una empresa consolidada y con gran proyección de futuro.</p>
            </li>
          </ul>
        </div>
        <div class="row">

        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <div class="col-sm-4 service-info">
            <div class="item">
            <a href="#" class="post-image view image_hover">     
            <img src="<?php echo e(url($cliente->imagen)); ?>" alt="" class="img-responsive zoom_img_effect">
            <h4><?php echo e($cliente->nombre); ?></h4>
            <br><br>
            </a>
            
                
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </div>
      </div>
    </section>
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>