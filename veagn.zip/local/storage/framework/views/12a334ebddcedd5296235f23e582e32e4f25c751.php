<?php $__env->startSection('title', 'Tienda'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Inner Header-->
    <section class="inner-banner2 clearfix">
      <div class="container clearfix">
        <h2>Tienda</h2>
      </div>
    </section>
    <section class="breadcumb-wrapper">
      <div class="container clearfix">
        <ul class="breadcumb">
          <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-home"></i> Inicio</a></li>
          <li><span>Tienda</span></li>
        </ul>
      </div>
    </section>
    <!-- News Page-->
    <section class="core-projects sectpad shop-page">
      <div class="container clearfix">
        <div class="row">
          <div class="col-md-4 col-sm-12 pull-left">
            <div>
              <!-- Search-->
              <div class="widget-search-blog">
                <div class="row widget-inner">
                  <form action="<?php echo e(url('solutions')); ?>" method="get" class="search-form">
                    <div class="input-group">
                      <input type="search" placeholder="Buscar producto..." name="search" class="form-control"><span class="input-group-addon">
                        <button type="submit"><i class="icon icon-Search"></i></button></span>
                    </div>
                  </form>
                </div>
              </div>
              <div class="single-sidebar-widget">
                <div class="sec-title">
                  <h2><span>Categorias</span></h2>
                </div>
                <div class="categories">
                  <ul>
                     <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                        <li><a href="<?php echo e(url('categorias')); ?>/<?php echo e($categoria->id); ?>"><?php echo e($categoria->nombre); ?></a></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-8 col-sm-12 pull-right">
            <!-- News-->
            <div class="section_header color">
            <?php if(isset($search)): ?>
            <h2>Resultados para "<?php echo e($search); ?>"</h2>
            <?php elseif(isset($cat)): ?>
            <h2><?php echo e($cat->nombre); ?></h2>
            <?php else: ?>
            <h2>Todos los productos</h2>
            <?php endif; ?>
              
            </div>
         
            <?php $c=1;?>
            <div class="row shop-item-wrapper">

            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
              <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="single-shop-item">
                <a href="<?php echo e(url('Producto')); ?>/<?php echo e($producto->id); ?>">
                <?php if($producto->imagen!=""): ?>
                 <div class="img-box"><img src="<?php echo e(url($producto->imagen)); ?>" height="200" alt="Awesome Image"></div>
                <?php else: ?>
                 <div class="img-box"><img src="<?php echo e(url('public/frontend/images/sinimagen.png')); ?>" width="100%" alt="Awesome Image"></div>
                <?php endif; ?>
                 
                  <div class="content">
                      <h3><?php echo e($producto->nombre); ?></h3></a>
                      <span><?php echo e(str_limit(strip_tags($producto->descripcion), 80)); ?>...</span>
                  </div>
                </div>
              </div>
              

              <?php
              if($c==3)
              {
                echo '<div class="clearfix visible-xs"></div>';
                $c=0;
                echo "</div>";
                echo '<div class="row shop-item-wrapper">';
              }
              $c++;
              ?>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

              <?php if(count($productos)==0): ?>
              <h2>No se encontraron productos</h2>
              <?php endif; ?>


            </div>
          </div>
        </div>
      </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>