<?php

namespace Mailgun\Connection\Exceptions;

class InvalidCredentials extends \Exception
{
}
